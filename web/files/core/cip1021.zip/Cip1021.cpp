#include <windows.h>
#include <conio.h>
#include <string.h>
#include <stdio.h>

HANDLE m_hComm;
char strCommPort[5];
void ProcessCommandLine();
void ReadData();
BOOL InitComm();

int main(int argc, char* argv[])
{
	if(argc>1)ProcessCommandLine();
	else strcpy((char *)strCommPort, "COM1");
		//printf(_T("\n��������� ��� ������ ������ Cipher1023"));
		//printf(_T("\n�����: Cip1023 �, ��� �-����� �����(1-8), �� ��������� - 1"));
		//printf(_T("\nCopyright(C)Syntech Inf Co.,2002 ���.742-17-89,742-17-90"));
		//printf(_T("\n����:%s\n"),strCommPort);
		printf("\nReading Data From CipherLab 102X Barcode Reader");
		printf("\nUse: Cip1021 X,where X is Com port number(1-8), default = 1");
		printf("\nPress any key to terminate the programm.");
		printf("\nCopyright(C)Syntech Inf Co.,2002 tel.(095)742-17-89,742-17-90");
		printf("\nPort:%s\n",strCommPort);
		if(!InitComm())return -1;
	
		ReadData();
	
		if (m_hComm != INVALID_HANDLE_VALUE)
		{
			EscapeCommFunction(m_hComm, SETBREAK);
			CloseHandle(m_hComm);
			m_hComm = INVALID_HANDLE_VALUE;
		}
		
	return 0;
}

void ProcessCommandLine()
{
int z,nLen;
char c;
//LPSTR str;
char str[512];
strcpy(str,::GetCommandLine());
nLen=strlen(str);
for(z=0;z<nLen;z++)if(str[z]==' ')break;
c=str[z+1];
//printf("\nC:%c",str[z+1]);
switch(c)
	{
	case '1': strcpy((char *)strCommPort,"COM1");break;
	case '2': strcpy((char *)strCommPort,"COM2");break;
	case '3': strcpy((char *)strCommPort,"COM3");break;
	case '4': strcpy((char *)strCommPort,"COM4");break;
	case '5': strcpy((char *)strCommPort,"COM5");break;
	case '6': strcpy((char *)strCommPort,"COM6");break;
	case '7': strcpy((char *)strCommPort,"COM7");break;
	case '8': strcpy((char *)strCommPort,"COM8");break;
	default:  strcpy((char *)strCommPort,"COM1");break;
	} 
}

BOOL InitComm()
{
	DCB dcb;
//	m_hComm = CreateFile ("COM2", GENERIC_READ /*| GENERIC_WRITE*/,
//                 0, NULL, OPEN_EXISTING, /*0*/FILE_FLAG_OVERLAPPED, NULL);
	m_hComm = CreateFile((LPCTSTR)strCommPort, GENERIC_READ | GENERIC_WRITE,
                 0, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
	if (m_hComm == INVALID_HANDLE_VALUE) 
	{
		//MessageBox(::GetActiveWindow(),"���������� ������� COM ����", "������!",MB_OK);
	   MessageBox(::GetActiveWindow(),"Unable to open COM port!", "Error!",MB_OK);
	   return FALSE;
	}
	  
	GetCommState(m_hComm,&dcb);
	SetupComm (m_hComm, 256, 256);       // allocate transmit & receive buffer
    //dcb.BaudRate = CBR_115200;
	dcb.BaudRate = CBR_9600;
	dcb.ByteSize = 8;
    dcb.Parity = NOPARITY;
    dcb.StopBits = ONESTOPBIT;
    SetCommState (m_hComm, &dcb);
	SetCommMask(m_hComm, EV_BREAK | EV_RXCHAR);
	return TRUE;
}

void ReadData()
{
	BYTE		szBuffer[256];
	DWORD		dwEvtMask;
	DWORD		dwError;
	DWORD		dwBytes;
	COMSTAT		csStat;
	OVERLAPPED	o;
	o.hEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	int			nCount;
	char		strTemp[128];
	for(nCount=0;nCount<128;nCount++)strTemp[nCount]=0;
	nCount=0;
	for (; ;)
	{
		ResetEvent(o.hEvent);

	if (!WaitCommEvent(m_hComm, &dwEvtMask, &o))
	{
		if(kbhit())break;
		Sleep(100);
	}

		if (dwEvtMask & EV_BREAK)break;
		else if (dwEvtMask & EV_RXCHAR)
		{
			ClearCommError(m_hComm,&dwError, &csStat);
			ResetEvent(o.hEvent);
			if (!ReadFile(m_hComm, szBuffer, csStat.cbInQue, &dwBytes, &o))
			{
			//if (WaitForMultipleObjects(2, Handles, FALSE, INFINITE) == WAIT_OBJECT_0+1)break;
			Sleep(50);
			if(kbhit())break;
			}

			for (UINT i = 0; i < csStat.cbInQue; i++)
			{
			if(szBuffer[i]==13)
				{
					printf("\n%s",(char *)strTemp);
					for(nCount=0;nCount<128;nCount++)strTemp[nCount]=0;
					nCount=0;
					}
			else
				{
					strTemp[nCount]=szBuffer[i];
					nCount++;
				}
			}
			if(nCount>64)
						{
						for(nCount=0;nCount<128;nCount++)strTemp[nCount]=0;
						nCount=0;
						}
		}				

	}
}